/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//ST10454698 Sinethemba Ntsiba

public class KanBanBoard {

    public KanBanBoard(String login_Feature, String create_login_to_authencticate_users, String robyn, int par, String harrison, String to_Do) {
    }
    public static List<Task> tasks = new ArrayList<>();
    public static boolean isLoggedIn = false;

    public static void main(String[] args) {
        while (true) {
            if (!isLoggedIn) {
                String username = JOptionPane.showInputDialog("Enter username");
                String password = JOptionPane.showInputDialog("Enter password");

                if (loginUser(username, password)) {
                    isLoggedIn = true;
                    JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
                    showMenu();
                } else {
                    JOptionPane.showMessageDialog(null, returnLoginStatus(false));
                }
            } else {
                showMenu();
            }
        }
    }

    public static boolean checkTaskDescription(String description) {
        return description.length() <=50 ;
        
       // if (description.length() >= 50) {
        //    while (true) {
          //      JOptionPane.showMessageDialog(null, "Task Description length is incorrect, please enter less than 50 characters.");
            //    description = JOptionPane.showInputDialog("Please enter a task description of less than 50 characters:");
              //  if (description.length() < 50) {
                //    JOptionPane.showMessageDialog(null, "Task Description successfully captured");
                  //  return true;
               // } else {
                 //   JOptionPane.showMessageDialog(null, "TASK DESCRIPTION MUST NOT BE GREATER THAN 50 CHARACTERS.");
               // }
           // }
      //  } else {
        //    JOptionPane.showMessageDialog(null, "Task Description successfully captured");
          //  return true;
       // }
    }
    
    public static void showMenu() {
        String option = JOptionPane.showInputDialog(null, "Select an option:\n1. Add tasks\n2. Show report\n3. Quit", "EasyKanban", JOptionPane.PLAIN_MESSAGE);

        switch (option) {
            case "1" -> {
                if (isLoggedIn) {
                    addTasks();
                } else {
                    JOptionPane.showMessageDialog(null, "Please login first.");
                }
            }
            case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon");
            case "3" -> System.exit(0);
            default -> JOptionPane.showMessageDialog(null, "Invalid option");
        }
    }

    public static void addTasks() {
        Scanner scanner = new Scanner(System.in);
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks to add"));

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name");
            String taskDescription = JOptionPane.showInputDialog("Enter task description");
        while (!checkTaskDescription(taskDescription)){
            taskDescription = JOptionPane.showInputDialog("Please enter description (not more than 50 characters)");
        }
            
            String developerDetails = JOptionPane.showInputDialog("Enter developer details");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours"));
            String taskID = generateTaskID(taskName, developerDetails, i);
            String taskStatus = JOptionPane.showInputDialog("Select task status:\n1. To Do\n2. Done\n3. Doing");

            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskID, taskStatus);
            tasks.add(task);

            JOptionPane.showMessageDialog(null, task.getTaskDetails());
        }

        int totalHours = calculateTotalHours(tasks);
        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours);
    }

    public static String generateTaskID(String taskName, String developerDetails, int taskNumber) {
        String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
        String lastThreeLetters = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return firstTwoLetters + ":" + taskNumber + ":" + lastThreeLetters;
    }

    public static int calculateTotalHours(List<Task> tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.getTaskDuration();
        }
        return totalHours;
    }

    public static boolean loginUser(String username, String password) {
        if (checkUserName(username) && checkPasswordComplexity(password)) {
            // Here you can implement logic to check against stored usernames and passwords.
            return true; // Temporary placeholder for demonstration.
        }
        return false;
    }

    public static boolean checkUserName(String username) {
        // Check if username contains an underscore and is no more than five characters
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        // Check password complexity rules
        return password.length() >= 8 && // at least eight characters long
                password.matches(".*[A-Z].*") && // contains a capital letter
                password.matches(".*\\d.*") && // contains a number
                password.matches(".*[!@#$%^&*?()_+\\-={}].*"); // contains a special character
    }

    public static String returnLoginStatus(boolean isSuccess) {
        if (isSuccess) {
            return "Login successful";
        } else {
            return "Invalid username or password";
        }
    }

    static class Task {
        public String taskName;
        public String taskDescription;
        public String developerDetails;
        public int taskDuration;
        public String taskID;
        public String taskStatus;

        public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskID, String taskStatus) {
            this.taskName = taskName;
            this.taskDescription = taskDescription;
            this.developerDetails = developerDetails;
            this.taskDuration = taskDuration;
            this.taskID = taskID;
            this.taskStatus = taskStatus;
        }

        public String getTaskDetails() {
            return "Task Name: " + taskName + "\nTask Description: " + taskDescription + "\nDeveloper Details: " + developerDetails +
                    "\nTask Duration: " + taskDuration + " hours\nTask ID: " + taskID + "\nTask Status: " + taskStatus;
        }

        public int getTaskDuration() {
            return taskDuration;
        }
    }
}
