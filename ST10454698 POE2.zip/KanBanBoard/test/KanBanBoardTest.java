/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class KanBanBoardTest {
    
    public KanBanBoardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class KanBanBoard.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        KanBanBoard.main(args);
        
    }

    /**
     * Test of showMenu method, of class KanBanBoard.
     */
    @Test
    public void testShowMenu() {
        System.out.println("showMenu");
        KanBanBoard.showMenu();
        
    }

    /**
     * Test of addTasks method, of class KanBanBoard.
     */
    @Test
    public void testAddTasks() {
        System.out.println("addTasks");
        KanBanBoard.addTasks();
        
    }

    /**
     * Test of generateTaskID method, of class KanBanBoard.
     */
    @Test
    public void testGenerateTaskID() {
        System.out.println("generateTaskID");
        String taskName = "Login Feature";
        String developerDetails = "Harrison Robyn";
        int taskNumber = 1;
        String expResult = "LO:1:BYN";
        String result = KanBanBoard.generateTaskID(taskName, developerDetails, taskNumber);
        assertEquals(expResult, result);
    
        taskName = "create Task Feature";
        taskNumber = 0;
        developerDetails = "John Rike";
        expResult = "CR:0:IKE";
        result = KanBanBoard.generateTaskID(taskName, developerDetails, taskNumber);
        assertEquals(expResult, result);
        System.out.println(result);

        taskName = "create Task Feature";
        taskNumber = 1;
        developerDetails = "Michael Edward";
        expResult = "CR:1:ARD";
        result = KanBanBoard.generateTaskID(taskName, developerDetails, taskNumber);
        assertEquals(expResult, result);
        System.out.println(result);

        taskName = "create Task Feature";
        taskNumber = 2;
        developerDetails = "Faith Mbatha";
        expResult = "CR:2:THA";
        result = KanBanBoard.generateTaskID(taskName, developerDetails, taskNumber);
        assertEquals(expResult, result);
        System.out.println(result);

        taskName = "Create Task Feature";
        taskNumber = 3;
        developerDetails = "Sterling Ryland";
        expResult = "CR:3:AND";
       result = KanBanBoard.generateTaskID(taskName, developerDetails, taskNumber);
        assertEquals(expResult, result);
        System.out.println(result);
       
    }

    /**
     * Test of calculateTotalHours method, of class KanBanBoard.
     */
    @Test
     public void testCalculateTotalHours() {
        System.out.println("calculateTotalHours");
        
        KanBanBoard task1 = new KanBanBoard("Login Feature", "Create login to authenticate users", "Robyn Harrison", 10, "LO:0:SON", "To Do");
        KanBanBoard task2 = new KanBanBoard("Add task feature", "Create add task feature to add tasks for users", "Mike Smith", 8, "AD:1:ITH", "Doing");
        
        KanBanBoard.tasks.add(task1);
        KanBanBoard.tasks.add(task2);
        
        int expectedTotalHours = 18;
        int actual = KanBanBoard.calculateTotalHours(KanBanBoard.tasks);
        
        assertEquals(expectedTotalHours, actual);
    }

    /**
     * Test of loginUser method, of class KanBanBoard.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "";
        String password = "";
        boolean expResult = false;
        boolean result = KanBanBoard.loginUser(username, password);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of checkUserName method, of class KanBanBoard.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "";
        boolean expResult = false;
        boolean result = KanBanBoard.checkUserName(username);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of checkPasswordComplexity method, of class KanBanBoard.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "";
        boolean expResult = false;
        boolean result = KanBanBoard.checkPasswordComplexity(password);
        assertEquals(expResult, result);
            }

    /**
     * Test of returnLoginStatus method, of class KanBanBoard.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean isSuccess = false;
        String expResult = "";
        String result = KanBanBoard.returnLoginStatus(isSuccess);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of checkTaskDescription method, of class KanBanBoard.
     */
    @Test
    public void testCheckTaskDescription() {
        System.out.println("checkTaskDescription");
        String description = "Create Login to authenticate users";
        boolean expResult = true;
        boolean result = KanBanBoard.checkTaskDescription(description);
        assertEquals(expResult, result);
        
        JOptionPane.showMessageDialog(null,"Task successfully captured");
        
        
        description = "Create Add Task feature to add task users";
        expResult = true;
        result = KanBanBoard.checkTaskDescription(description);
        assertEquals(expResult, result);
        JOptionPane.showMessageDialog(null,"Task successfully captured");
        
        
    }
    
}
